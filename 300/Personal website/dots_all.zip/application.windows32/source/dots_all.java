import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.pdf.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class dots_all extends PApplet {

/*WIP sketches inspired by:
Devon Moodley, "Practice IQ": https://dribbble.com/shots/2371465-Practice-IQ
Jerome Herr, "colorful orbs": https://www.openprocessing.org/sketch/168279
Scott Murray, "Gesture Project": http://alignedleft.com/work/gesture-project
Unknown, "Minimal Motion": https://gfycat.com/gifs/detail/heavysociablegrub
PDF export based on https://processing.org/reference/libraries/pdf/index.html
Color palettes generated from http://coolors.co

Stipples: A Procedural Drawing Tool

The initial goal of the project was to create a looping animation with circles
moving uniformly and changing in size, color. etc.
With some tinkering in the code, the finished project morphed into
a drawing tool with five integrated color palettes
and user control over size, speed, opacity, and color of the dots.

# keys 1-5: cycle through color palettes
A: change alpha
R: change radius of dots
S: change speed
Left mouse click: capture current frame*/



int state = 1;

int berBg;
int conBg;
int eggBg;
int fireBg;
int seaBg;

boolean runonce = true;

Dots[] points = new Dots[12];

public void setup() {
  berBg = color(0xff7765E3);
  conBg = color(0xff52b2cf);
  eggBg = color(0xffefe5dc);
  fireBg = color(0xffbf3100);
  seaBg = color(0xff003459);

  
  //beginRecord(PDF, "berry.pdf");
  background(berBg);

  //create the dots
  for (int i = 0; i < points.length; i++) {
    points[i] = new Dots();
  }
}

public void draw() {
  if (runonce) {
    if (state == 1) {
      background(berBg);
    }

    if (state == 2) {
      background(conBg);
    }

    if (state == 3) {
      background(eggBg);
    }

    if (state == 4) {
      background(fireBg);
    }

    if (state == 5) {
      background(seaBg);
    }  
    runonce = false;
  }

  for (int i = 0; i < points.length; i++) {
    points[i].display();
  }
}

public void keyPressed() {

  //toggle color palettes
  if (key == '1') {
    state = 1;
    runonce = true;
  }

  if (key == '2') {
    state = 2;
    runonce = true;
  }

  if (key == '3') {
    state = 3;
    runonce = true;
  }

  if (key == '4') {
    state = 4;
    runonce = true;
  }

  if (key == '5') {
    state = 5;
    runonce = true;
  }
}

public void mousePressed() {
  if (mouseButton == LEFT) {
    saveFrame("dots-####.png");
  }
}
class Dots {
  //constructors
  float rad; //initial radius of dots
  float bigRadX, bigRadY; //maximum distance from center dots may travel
  float speedX, speedY; //initial speeds of the dots
  float intX, intY; //starting positions of the dots
  float maxX, maxY; //set max dist down/right
  float minX, minY; //set max dist up/left
  float a; //alpha

  int ber1, ber2, ber3, ber4;
  int con1, con2, con3, con4;
  int egg1, egg2, egg3, egg4;
  int fire1, fire2, fire3, fire4;
  int sea1, sea2, sea3, sea4;

  int[] berries ={
    color(0xffEDD3C4), 
    color(0xffC8ADC0), 
    color(0xff080708), 
    color(0xff3b9ce2)
  };
  int berry;

  int[] confettis ={
    color(0xffd4afb9), 
    color(0xffd1cfe2), 
    color(0xff9cadce), 
    color(0xff7ec4cf)
  };
  int confetti;

  int[] eggs ={
    //egg palette
    color(0xffd0b8ac), 
    color(0xfff3d8c7), 
    color(255), 
    color(0xfff2f4f2)
  };
  int egg;

  int[] fires ={
    color(0xffff4e00), 
    color(0xffede37d), 
    color(0xfff5bb00), 
    color(0xffec9f05)
  };
  int fire;

  int[] seas ={
    color(0xff00a7e1), 
    color(0xff00171f), 
    color(255), 
    color(0xff007ea7)
  };
  int sea;

  //fields
  Dots() {
    rad = 10;
    speedX = random(-5, 5);
    speedY = random(-5, 5);
    intX = width/2;
    intY= height/2;
    maxX = width;
    maxY = height;
    minX = 0;
    minY = 0;
    a = random(25, 255);

    berry = PApplet.parseInt(random(berries.length));
    confetti = PApplet.parseInt(random(confettis.length));
    egg = PApplet.parseInt(random(eggs.length));
    fire = PApplet.parseInt(random(fires.length));
    sea = PApplet.parseInt(random(seas.length));
  }

  public void display() {
    noStroke();

    //DETERMINE COLORS
    if (state == 1) {
      fill(berries[berry], a);
    }

    if (state == 2) {
      fill(confettis[confetti], a);
    }

    if (state == 3) {
      fill(eggs[egg], a);
    }

    if (state == 4) {
      fill(fires[fire], a);
    }

    if (state == 5) {
      fill(seas[sea], a);
    }

    //draw dots
    ellipse(intX, intY, rad, rad);

    //make the dots move
    intX = intX + speedX;
    if (intX > maxX) {
      intX = maxX;
      speedX = -speedX;
      speedY = -speedY; //y speed also changes to ensure slope of line is constant
    }
    if (intX < minX) {
      intX = minX;
      speedX = -speedX;
      speedY = -speedY;
    }

    intY = intY + speedY;
    if (intY > maxY) {
      intY = maxY;
      speedX = -speedX; //x speed also changes to ensure ^^^
      speedY = -speedY;
    }
    if (intY < minY) {
      intY = minY;
      speedX = -speedX;
      speedY = -speedY;
    }

    //change dots' properties

    if (keyPressed) {
      
      //change velocity
      if (key == 's' | key == 'S') {
        speedX = speedX + random(-5.0f, 5.0f);
        speedY = speedY + random(-5.0f, 5.0f);
      }

      //change size
      if (key == 'r' | key == 'R') {
        rad = rad + random(-5.0f, 5.0f);
      }
      
      //change alpha
      if (key == 'a' | key == 'A') {
       a = random(25,255); 
      }
    }

    //set min and max radius
    if (rad < 1.0f) {
      rad = 1.0f;
    }
    if (rad > 30.0f) {
      rad = 30.0f;
    }
  }
}
  public void settings() {  size(1280, 720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "dots_all" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
